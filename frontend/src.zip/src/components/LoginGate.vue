<template>
  <div class="card col">
    <div class="row" style="justify-content:space-between; align-items:center;">
      <b>免登录体验模式</b>
      <router-link to="/login" class="btn ghost">登录</router-link>
    </div>
    <small class="hint">你可以直接开始语音/文字聊天，但不会保存历史记录与个性化设置。</small>
  </div>
</template>
<script setup>
</script>